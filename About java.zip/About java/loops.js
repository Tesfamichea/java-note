// JavaScript Loops
/*Looping in programming languages is a feature which facilitates the 
execution of a set of \instructions/functions repeatedly while some condition evaluates to true.*/
// for - loops through a block of code a number of times
// for/in - loops through the properties of an object
// while - loops through a block of code while a specified condition is true
// do/while - also loops through a block of code while a specified condition is true

//For Loop
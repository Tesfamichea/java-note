//JavaScript methods are actions that can be performed on objects.
    
//A JavaScript **method** is a property containing a **function definition**.

/*A method in Java is a block of code that, when called, performs specific actions mentioned in it. 
For instance, if you have written instructions to draw a circle in the method, it will do that task. 
You can insert values or parameters into methods, and they will only be executed when called.*/

/*
HTML Events
n HTML event can be something the browser does, or something a user does.
Here are some examples of HTML events:
    An HTML web page has finished loading
    An HTML input field was changed
    An HTML button was clicked
<element event="some JavaScript">
    */
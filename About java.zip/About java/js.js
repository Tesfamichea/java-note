// javascript
//The JavaScript programming language is text-put together and can be utilized with respect to both client and server-side. 
//It controls sight and sound inside website pages and permits them to become intuitive. JavaScript empowers a developer to do many things like adding animation to images or updating content automatically on a page.
//-It is the most popular and extensively used client-side scripting language
//-JavaScript is a scripting language that manipulates the content returned from a web server to add interactivity and dynamic effects to online pages.
